public class Chest {
	private Item item = new Item("Pure-Soul", "Pure-Soul");
	
	public Chest() {

	}

	public Item getItem() {
		return item;
	}
	
}