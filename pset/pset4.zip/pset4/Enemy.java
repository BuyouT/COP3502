public class Enemy {
	private Item item = new Item("Dark-Soul", "Dark-Soul"); 
	
	public Enemy() {

	}

	public Item getItem() {
		return item;
	}

}